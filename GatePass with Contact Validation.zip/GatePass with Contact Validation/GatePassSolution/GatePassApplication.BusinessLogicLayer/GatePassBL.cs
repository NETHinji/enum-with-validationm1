﻿using GatePassApplication.DataAccessLayer;
using GatePassApplication.Entities;
using GatePassApplication.GatePassExceptions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace GatePassApplication.BusinessLogicLayer
{
    public class GatePassBL
    {
        private static bool ValidateVisitor(GatePass gateP)
        {
            
            StringBuilder sb = new StringBuilder();
            bool validVisitor = true;

            //===================Validating All Fields=======================

            if (gateP.VisitorName == string.Empty)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Visitor Name Required");

            }
            if (gateP.ContactPerson == string.Empty)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Contact Person Name Required");

            }
            /*if (gateP.DateOfVisit == string.Empty)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Date Of Visit Required");

            }*/
            if (gateP.PurposeOfVisit == string.Empty)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Purpose of Visit Required");

            }

            //if(gateP.ContactNo < 8000000000 || gateP.ContactNo > 9999999999)
            //{
            //    validVisitor = false;
            //    sb.Append(Environment.NewLine + "Purpose of Visit Required");
            //}

            if(!(gateP.PurposeOfVisit==GatePassApplication.Entities.VisitPurpose.Interview.ToString() || gateP.PurposeOfVisit==GatePassApplication.Entities.VisitPurpose.Meeting.ToString() || gateP.PurposeOfVisit==GatePassApplication.Entities.VisitPurpose.Training.ToString()))
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Enter Valid Purpose(Interview,Training,Meeting)");


            }
            if (!Regex.Match(Convert.ToString(gateP.ContactNo), @"[7-9]{1}[0-9]{9}$").Success)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }

            if (validVisitor == false)
                throw new GatePassException(sb.ToString());
            return validVisitor;
        }
        public bool AddVisit(GatePass gatePass)
        {
            bool visitorAdded = false;
            try
            {
                if (ValidateVisitor(gatePass))
                { 
                    GatePassDAL gpDAL = new GatePassDAL();
                    visitorAdded = gpDAL.AddVisitor(gatePass);
                }
            }
            catch (SystemException sys)
            {

                throw new GatePassException(sys.Message);
            }
            return visitorAdded;
        }

        public GatePass SearchVisitorByID(int gpID)
        {
            GatePass searchVisitor = null;
            try
            {
                GatePassDAL guestDAL = new GatePassDAL();
                searchVisitor = guestDAL.SearchGatePassDAL(gpID);
            }
            catch (GatePassException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVisitor;
        }
        public List<GatePass> GetAllGatePasses()
        {
            //List<GatePass> gatePassList = null;
            try
            {
                GatePassDAL gpDAL = new GatePassDAL();
                List<GatePass> gatePassList = gpDAL.GetAllGatePass();
                return gatePassList;
            }
            catch (GatePassException ex)
            {
                throw ex;
            }
            
        }

    }  
   
}
